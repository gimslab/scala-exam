/*
 * Copyright 2001-2013 Artima, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.scalactic

import org.scalatest._
import scala.collection.GenSeq
import scala.collection.GenMap
import scala.collection.GenSet
import scala.collection.GenIterable
import scala.collection.GenTraversable
import scala.collection.GenTraversableOnce
import scala.collection.{mutable,immutable}

class ConversionCheckedSetEqualityConstraintsSpec extends Spec with NonImplicitAssertions with ConversionCheckedTripleEquals with SetEqualityConstraints {

  case class Super(size: Int)
  class Sub(sz: Int) extends Super(sz)

  val super1: Super = new Super(1)
  val sub1: Sub = new Sub(1)
  val super2: Super = new Super(2)
  val sub2: Sub = new Sub(2)
  val nullSuper: Super = null

  case class Fruit(name: String)
  class Apple extends Fruit("apple")
  class Orange extends Fruit("orange")

  object `the SetEqualityConstraints trait` {

    def `should allow any Set to be compared with any other Set, so long as the element types of the two Sets adhere to the equality constraint in force for those types` {
      assert(mutable.HashSet(1, 2, 3) === immutable.HashSet(1, 2, 3))
      assert(mutable.HashSet(1, 2, 3) === immutable.HashSet(1L, 2L, 3L))
      assert(mutable.HashSet(1L, 2L, 3L) === immutable.HashSet(1, 2, 3))
      assert(immutable.HashSet(1, 2, 3) === mutable.HashSet(1L, 2L, 3L))
      assert(immutable.HashSet(1L, 2L, 3L) === mutable.HashSet(1, 2, 3))
      assert(mutable.HashSet(new Apple, new Apple) === immutable.HashSet(new Fruit("apple"), new Fruit("apple")))
      assert(immutable.HashSet(new Fruit("apple"), new Fruit("apple")) === mutable.HashSet(new Apple, new Apple))
      assertTypeError("mutable.HashSet(new Apple, new Apple) === immutable.HashSet(new Orange, new Orange)")
      assertTypeError("immutable.HashSet(new Apple, new Apple) === mutable.HashSet(new Orange, new Orange)")
      assertTypeError("immutable.HashSet(new Orange, new Orange) === mutable.HashSet(new Apple, new Apple)")
      assertTypeError("mutable.HashSet(new Orange, new Orange) === immutable.HashSet(new Apple, new Apple)")
    }
  }
}

